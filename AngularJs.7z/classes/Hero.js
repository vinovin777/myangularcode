import {Person} from './Person.js'

export class Hero extends Person {
    constructor(fname,lname,pw){
        super(pw);
        this.fname=fname;
        this.lname=lname;
        this._secret="Top Secret"
    }
    fullname(){
        return this.fname+" "+this.lname;
    }

    get secret(){
        return this._secret;

    }

    set secret(s){
        this._secret=s;
    }
}