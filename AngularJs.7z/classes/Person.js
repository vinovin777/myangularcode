export class Person{
    constructor(pow){
        this.pow=pow;
    }

}