var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
import { Person } from "./Person.js";
var Hero = /** @class */ (function (_super) {
    __extends(Hero, _super);
    function Hero(firstName, lastname, pw) {
        var _this = _super.call(this, pw) || this;
        _this.firstName = firstName;
        _this.lastname = lastname;
        _this._secret = "Top Secret";
        return _this;
    }
    Hero.prototype.fullname = function () {
        return this.firstName + " " + this.lastname;
    };
    Object.defineProperty(Hero.prototype, "secret", {
        get: function () {
            return this._secret;
        },
        set: function (s) {
            this._secret = s;
        },
        enumerable: true,
        configurable: true
    });
    Hero.prototype.showpower = function () {
        return this.pow;
    };
    return Hero;
}(Person));
export { Hero };
