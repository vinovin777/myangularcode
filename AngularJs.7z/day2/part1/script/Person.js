var Person = /** @class */ (function () {
    // power:number
    // constructor(pow:number){
    //     this.power=pow;
    // }
    function Person(pow) {
        this.pow = pow;
    }
    return Person;
}());
export { Person };
