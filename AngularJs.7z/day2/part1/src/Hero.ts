import {Person} from "./Person.js"

interface IHero {


firstName:string;
lastname:string;
fullname():string;
showpower():number;


}



export class Hero extends Person implements IHero {
 
    
    private _secret:string
    constructor(public firstName:string,
        public lastname:string,
        pw:number){
        super(pw);
        this._secret="Top Secret"
    }
    fullname():string{
        return this.firstName+" "+this.lastname;
    }

    get secret():string{
        return this._secret;

    }

    set secret(s){
        this._secret=s;
    }

    showpower(): number {
        return this.pow;
    }
}