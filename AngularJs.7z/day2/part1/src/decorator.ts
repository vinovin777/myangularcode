let addPower=function(power:number){
    return function(targetclass:any){
        return class {
            title=new targetclass().title;
            power=power;
        }