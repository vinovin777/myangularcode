import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
  <div class="box">
    <h1>{{title.toUpperCase()}}</h1>
    <h1 [innerHTML]="title"></h1>
    <h1 [textContent]="title"></h1>
    <h1 [innerText]="title"></h1>

    <h1 bind-innerHTML="title"></h1>
    <button (click)="clickHandler()">Click Me</button>
        <hr>
    <input (keydown.enter)="onEnter()" type="text">
    <hr>
    <img src="{{pic}}" alt="batty">
    <img [src]="pic" alt="batty">
    <img bind-src="pic" alt="batty">

    <input #i1 type="text">
    <button (click)="showValue(i1.value)">Show Text</button>

    <app-citi></app-citi>

  </div>
  `,
  styles: [`
  .box{
    border:3px solid grey;
    background-color:grey;
  }`]
})
export class AppComponent {
  title = 'step1-helloword';
  pic = 'assets/img/batman1.jpg';


  clickHandler() {
    alert("Hiiiiiii")
  }

  onEnter() {
    console.log("Enter Pressed")
  }

  showValue(txt: string) {
    alert(txt);
  }


  enterLogic = () => console.log("Enter Pressed")
}
