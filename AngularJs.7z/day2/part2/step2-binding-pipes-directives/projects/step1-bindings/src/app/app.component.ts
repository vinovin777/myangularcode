import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `<h1>{{title}}<h1>
  <input #i1 (input)="content=i1.value"  [value]="content" type="text">
  <input [(ngModel)]="content" type="text">
  <h1>{{content}}</h1>
  <input [(ngModel)]="colorBox" type="text">
  <div #d1 [ngClass]="['bdr',colorBox]" (click)='onBoxClick(d1)'></div>
  <hr>
  <input [(ngModel)]="agree" type="checkbox">
  <div [class.bdr]="agree">
    <h2>Welcome to your life</h2>
  </div>
  <hr>
  <input [(ngModel)]="color" type="text">
  <h1 [style.background-color]="color">Hello Citibank</h1>
  <h1 [ngStyle]="{'color':'white','background-color':'blue'}">Hello Citibank</h1>
  `,
  styles : [`
  .bdr{
    border : 10px dotted red;
  }
  .orangeBox{
    width : 200px;
    height : 200px;
    background-color : orange;
    margin : auto;
  }
  .greenBox{
    width : 200px;
    height : 200px;
    background-color : green;
    margin : auto;
  }
  .silverBox{
    width : 200px;
    height : 200px;
    background-color : silver;
    margin : auto;
  }
  `]
  
})
export class AppComponent {
  title = 'step1-bindings';

  content='NOTHING';

  colorBox='orangeBox';
  color = 'pink';
  agree = true;

  onBoxClick(e:any){
  console.log(e.detail);
  }
}
