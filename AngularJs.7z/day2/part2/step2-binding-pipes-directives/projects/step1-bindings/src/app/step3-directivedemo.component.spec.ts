import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Step3DirectivedemoComponent } from './step3-directivedemo.component';

describe('Step3DirectivedemoComponent', () => {
  let component: Step3DirectivedemoComponent;
  let fixture: ComponentFixture<Step3DirectivedemoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Step3DirectivedemoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Step3DirectivedemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
