import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-step3-directivedemo',
  template: `
    <p ngNonBindable>
      {{step3-directivedemo works!}}
    </p>
    <input [(ngModel)]="agree" type="checkbox">
    <p *ngIf="agree">
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates assumenda officiis cumque eum, totam dolor, quos ad harum. Impedit dolore amet ullam, tenetur sit adipisci dolor voluptatibus! Dolores, ad porro?
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nulla id nisi doloribus labore ullam voluptatum atque exercitationem aperiam, placeat hic debitis minus dolor mollitia ex veniam iste deleniti, dolore enim!
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Recusandae est ut sapiente labore itaque doloremque, eos quibusdam? Earum praesentium, temporibus reprehenderit deserunt cum ut consectetur sunt molestiae. Sit, aliquam, impedit!
    </p>
    <input [(ngModel)]="power" type="range" min="4" max="10" step="1">
    <h2>Power now is : {{ power }}</h2>
    <h2> Ironman is now 
     <span [ngSwitch]="power">
       <span *ngIf="power==5" >Weak</span>
       <span *ngIf="power<5" >Recovering</span>
       <span *ngIf="power>5" >Strong</span>
     </span>
    </h2>
    <ul>
    <li *ngFor="let hero of herolist"><img src={{hero.poster}} alt="fDG" /></li>
    </ul>
  `,
  styles: []
})
export class Step3DirectivedemoComponent{

  agree=true;
  power=5;

  herolist = [{
    "sl": 1,
    "title": "Batman",
    "gender": "male",
    "firstname": "Bruce",
    "lastname": "Wayne",
    "city": "Gotham",
    "ticketprice": 123.45,
    "releasedate": "1/26/2018",
    "poster": "assets/img/batman.jpg"
},
{
    "sl": 2,
    "title": "Superman",
    "gender": "male",
    "firstname": "Clark",
    "lastname": "Kent",
    "city": "Metropolis",
    "ticketprice": 178.67,
    "releasedate": "1/27/2018",
    "poster": "assets/img/superman.jpg"
},
{
    "sl": 3,
    "title": "Ironman",
    "gender": "male",
    "firstname": "Tony",
    "lastname": "Stark",
    "city": "New York",
    "ticketprice": 122.90,
    "releasedate": "1/27/2018",
    "poster": "assets/img/ironman.jpg"    
}, {
    "sl": 4,
    "title": "Phantom",
    "gender": "male",
    "firstname": "Kit",
    "lastname": "Walker",
    "city": "Bhangala",
    "ticketprice": 98.64,
    "releasedate": "1/27/2018",
    "poster": "assets/img/phantom.jpg"
}, {
    "sl": 5,
    "title": "Spiderman",
    "gender": "male",
    "firstname": "Peter",
    "lastname": "Parker",
    "city": "New York",
    "ticketprice": 451.34,
    "releasedate": "9/26/2018",
    "poster": "assets/img/spiderman.jpg"
},
{
    "sl": 6,
    "title": "Wonder Women",
    "gender": "female",
    "firstname": "Princess",
    "lastname": "Diana",
    "city": "Amazon",
    "ticketprice": 341.34,
    "releasedate": "11/26/2018",
    "poster": "assets/img/wonderwoman.png"
}];
  }


