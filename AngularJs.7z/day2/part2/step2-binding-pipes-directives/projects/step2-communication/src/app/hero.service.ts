export class HeroService{
    herolist=[]

    heros(){
        return this.herolist;
    }
}