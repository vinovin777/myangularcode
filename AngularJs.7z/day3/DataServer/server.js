let express=require("express");
let cors=require("cors");
let data=require("./hero.json")
let bodyParser=require("body-parser")
let app=express();
app.use(bodyParser.json());
app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));
app.get("/",function(req,res){
    return res.send(data)
})


app.listen(8080);
console.log("sever started")