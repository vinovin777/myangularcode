import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { FormComponent } from './templateform.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ReactiveFormGroup } from './reactiveforms.component';

@NgModule({
  declarations: [
    FormComponent,ReactiveFormGroup
  ],
  imports: [
    BrowserModule,FormsModule,ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [ReactiveFormGroup]
})
export class AppModule { }
