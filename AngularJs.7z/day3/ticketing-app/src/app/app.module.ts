import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { TicketingComponent } from './citi.ticketing.component';
import { MainComponent } from './main.component';
import { HeaderComponent } from './header.component';
import { HttpClientModule } from '@angular/common/http';


@NgModule({
  declarations: [
    TicketingComponent,
    MainComponent,HeaderComponent
  ],
  imports: [
    BrowserModule,HttpClientModule
  ],
  providers: [],
  bootstrap: [MainComponent]
})
export class AppModule { }
