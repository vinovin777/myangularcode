import { Component, Input } from '@angular/core';
// document.querySelector(".citi")
@Component({
    selector: 'app-ticket',
    templateUrl:'ticket.html',
    styles: [`
        .orangebox{
            background-color:orange;
        }`
    ]



})
export class TicketingComponent {
    @Input('data') herolist = [];
}