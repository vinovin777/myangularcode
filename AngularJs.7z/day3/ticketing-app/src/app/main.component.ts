import { Component, OnInit } from '@angular/core';
import { HeroService } from './hero.service';

@Component({
selector:'app-main',
templateUrl:'main.html',
providers:[HeroService]

})
export class MainComponent implements OnInit{
    herolist:any;
    constructor(private heroService:HeroService){}
    ngOnInit(): void {
        this.heroService.heroes().subscribe(res=>this.herolist=res)
    }
    

}