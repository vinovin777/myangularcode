let express=require("express");
let app=express();
app.use(express.static(__dirname))
app.get("/",function(req,res){
    // res.send("WELCOME")
    res.sendFile(__dirname+"/step10-modules.html")
});

app.listen(8888)
console.log(`app running in 8888`)