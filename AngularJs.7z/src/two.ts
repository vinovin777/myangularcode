let user:(string|Array<string>) =["vinoth"];

function adder(num1:number=0,num2:number=0,num3?:number){
    return num1+num2;
}